// api/server.js
const express = require('express');
const mongoose = require('mongoose');
const bodyParser = require('body-parser');
const GroceryItem = require('./models/Grocery');
const dotenv = require('dotenv');
const cors = require('cors');


dotenv.config();

const app = express();
app.use(cors());
const port = process.env.PORT || 5000;

// Connect to MongoDB
mongoose.connect(process.env.MONGODB_URI).then(() => {
  console.log('Connected to MongoDB');
})
.catch((error) => {
  console.error('Error connecting to MongoDB:', error);
});

// Middleware
app.use(bodyParser.json());

const corsOptions = {
  origin: 'http://localhost:5173',
};
// API routes

// Get all grocery items
app.get('/api/grocery', cors(corsOptions), async (req, res) => {
  try {
    const groceryItems = await GroceryItem.find();
    res.json(groceryItems);
  } catch (error) {
    console.error(error);
    res.status(500).send('Internal Server Error');
  }
});

// Add a new grocery item
app.post('/api/grocery', cors(corsOptions), async (req, res) => {
  const { name, quantity } = req.body;

  try {
    const newGroceryItem = new GroceryItem({ name, quantity });
    await newGroceryItem.save();
    res.json(newGroceryItem);
  } catch (error) {
    console.error(error);
    res.status(500).send('Internal Server Error');
  }
});

// Update a grocery item
app.put('/api/grocery/:id', cors(corsOptions), async (req, res) => {
  const { id } = req.params;
  const { name, quantity } = req.body;

  try {
    const updatedGroceryItem = await GroceryItem.findByIdAndUpdate(
      id,
      { name, quantity },
      { new: true }
    );
    res.json(updatedGroceryItem);
  } catch (error) {
    console.error(error);
    res.status(500).send('Internal Server Error');
  }
});

// Delete a grocery item
app.delete('/api/grocery/:id', cors(corsOptions), async (req, res) => {
  const { id } = req.params;
  try {
    await GroceryItem.findByIdAndRemove(id);
    res.json({ success: true });
  } catch (error) {
    console.error(error);
    res.status(500).send('Internal Server Error');
  }
});

// Start the server
app.listen(port, () => {
  console.log(`Server is running on port ${port}`);
});
